#-------------------------------------------------#
# Title: Assignment 6
# Dev:   Michael Long
# Date:  12/1/2018
# ChangeLog: Added class and defined functions.

#-------------------------------------------------#

class ToDo(object):

	def __init__(self):
		self.lstTable = []

	def loadFile(self, fileName):
		objFile = open(fileName, "r")
		for line in objFile:
			strData = line.split(",")  # readline() reads a line of the data into 2 elements
			self.addItem(strData[0].strip(), strData[1].strip())
		objFile.close()

	def printTable(self):
		print("******* The current items ToDo are: *******")
		for row in self.lstTable:
			print(row["Task"] + "(" + row["Priority"] + ")")
		print("*******************************************")

	def addItem(self, task, priority):
		dicRow = {"Task": task, "Priority": priority}
		self.lstTable.append(dicRow)

	def removeItem(self, keyToRemove):
		intRowNumber = 0
		while (intRowNumber < len(self.lstTable)):
			currentRowKey = str(list( dict( self.lstTable[intRowNumber] ).values())[0])
			if (keyToRemove == currentRowKey):  # the values function creates a list!
				del self.lstTable[intRowNumber]
				blnItemRemoved = True
			# end if
			intRowNumber += 1
		return blnItemRemoved

	def saveFile(self, fileName):
		objFile = open(fileName, "w")
		for dicRow in self.lstTable:
			objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
		objFile.close()


#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
objTodoList = ToDo()

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
objTodoList.loadFile(objFileName)

# Step 2
# Display a menu of choices to the user
while(True):
	print ("""
	Menu of Options
	1) Show current data
	2) Add a new item.
	3) Remove an existing item.
	4) Save Data to File
	5) Exit Program
	""")
	strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
	print()#adding a new line

	# Step 3
	# Show the current items in the table
	if (strChoice.strip() == '1'):
		objTodoList.printTable()
	# Step 4
	# Add a new item to the list/Table
	elif(strChoice.strip() == '2'):
		strTask = str(input("What is the task? - ")).strip()
		strPriority = str(input("What is the priority? [high|low] - ")).strip()
		objTodoList.addItem(strTask, strPriority)

		#4a Show the current items in the table
		objTodoList.printTable()
		continue #to show the menu

	# Step 5
	# Remove a new item to the list/Table
	elif(strChoice == '3'):
		#5a-Allow user to indicate which row to delete
		strKeyToRemove = input("Which TASK would you like removed? - ")
		blnItemRemoved = objTodoList.removeItem(strKeyToRemove) #Creating a boolean Flag
		#end for loop
		#5b-Update user on the status
		if(blnItemRemoved == True):
			print("The task was removed.")
		else:
			print("I'm sorry, but I could not find that task.")

		#5c Show the current items in the table
		objTodoList.printTable()
		continue #to show the menu

	# Step 6
	# Save tasks to the ToDo.txt file
	#@staticmethod
	#def Save(self):
	elif(strChoice == '4'):
		#5a Show the current items in the table
		objTodoList.printTable()
		#5b Ask if they want save that data
		if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
			objTodoList.saveFile()
			input("Data saved to file! Press the [Enter] key to return to menu.")
		else:
			input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
		continue #to show the menu

	elif (strChoice == '5'):
		break #and Exit the program
