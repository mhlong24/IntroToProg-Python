# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Michael Long
# Date:  November 21, 2018
# ChangeLog: (Who, When, What)
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------
objFileName = open("C:\_PythonClass\Assignment05\Todo.txt", "w")
strData1 = "Clean House,low\n"
strData2 = "Pay Bills,high\n"
objFileName.write(strData1)
objFileName.write(strData2)
objFileName.close()
objFileName = open("C:\_PythonClass\Assignment05\Todo.txt", "r")
print(objFileName.read())

#dicRow = {"Task":,"Priority":}
lstRow1 = ["Clean House","low"]
lstRow2 = ["Pay Bills","high"]
lstNewRow = []
lstRemoveRow = ()

dicRow1 = {"Task":lstRow1[0],"Priority":lstRow1[1]}
dicRow2 = {"Task":lstRow2[0],"Priority":lstRow2[1]}
lstTable = [dicRow1,dicRow2]

print(lstTable[0])

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"


# Step 2 - Display a menu of choices to the user
while (True):
	print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove the newest / last item on list.
    4) Save Data to File
    5) Exit Program
    """)
	strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
	print()  # adding a new line

	# Step 3 -Show the current items in the table
	if (strChoice.strip() == '1'):
		for objRow in lstTable:
			print(objRow)
		continue
	# Step 4 - Add a new item to the list/Table
	elif (strChoice.strip() == '2'):
		lstNewRow = [input("Enter the Task: "), ",", input("Enter the Priority: "), "/n"]
		objFileName = open("C:\_PythonClass\Assignment05\Todo.txt", "a")
		objFileName.write(lstNewRow[0])
		objFileName.write(lstNewRow[1])
		objFileName.write(lstNewRow[2])
		dicNewRow = {"Task": lstNewRow[0], "Priority": lstNewRow[2]}
		lstTable.append(dicNewRow)
		print(lstTable)
		continue
	# Step 5 - Remove a new item to the list/Table
	elif (strChoice == '3'):
		lstTable.pop()
		continue
	# Step 6 - Save tasks to the ToDo.txt file
	elif (strChoice == '4'):
		objFileName.close()
		print("Data saved.")
		for objRow in lstTable:
			print(objRow)
		continue
	elif (strChoice == '5'):
		break  # and Exit the program


